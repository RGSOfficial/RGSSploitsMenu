@echo off
powershell -NoProfile -Command "(New-Object -ComObject WScript.Shell).SendKeys('{F11}')"
setlocal enabledelayedexpansion
chcp 65001 >nul
color 02
for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do set "ESC=%%b"

set "Red=%ESC%[31m"
set "Green=%ESC%[32m"
set "Blue=%ESC%[34m"
set "Yellow=%ESC%[33m"
set "Cyan=%ESC%[36m"
set "Reset=%ESC%[0m"

set "appsfolder=%~dp0Apps"
:label:
echo %Red%__________  ________  _________ _________      .__          .__  __                    __________  ________  _________   _____                        
echo %Red%\______   \/  _____/ /   _____//   _____/_____ ^|  ^|   ____ ^|__^|/  [_  ______            \______   \/  _____/ /   _____/  /     \   ____   ____   __ __ 
echo %Green%  ^|       _/   \  ___ \_____  \ \_____  \\____ \^|  ^|  /  _ \^|  \   __\/  ___/   ______    ^|       _/   \  ___ \_____  \  /  \ /  \_/ __ \ /    \ ^|  ^|  \
echo %Green%  ^|    ^|   \    \_\  \/        \/        \  ^|_^> ^>  ^|_(  ^<_^> )  ^|^|  ^|  \___ \   /_____/    ^|    ^|   \    \_\  \/        \/  /    Y    \  ___/^|   ^|  \^|  ^|  /
echo %Blue%  ^|____^|_  /\______  /_______  /_______  /   __/^|____/\____/^|__^|^|__^| /____  ^>            ^|____^|_  /\______  /_______  /\____^|__  /\___  ^>___^|  /____/ 
echo %Blue%         \/        \/        \/        \/^|__^|                             \/                    \/        \/        \/         \/     \/     \/        %Reset%
:Main:
set /p console="%Red%RGSMenu %Green%(%Red%Console%Green%) %Yellow%>> "

if "!console!"=="help" goto :Help:
if "!console!"=="hostip" goto :HostIp:
if "!console!"=="iphost" goto :IpHost:
if "!console!"=="mlookup" goto :MacLookup:
if "!console!"=="myip" goto :MyIP:
if "!console!"=="pcheck" goto :PortCheck:
if "!console!"=="dlookup" goto :DNSLookup:
if "!console!"=="speed" goto :Speed:
if "!console!"=="sysinfo" goto :SysInfo:
if "!console!"=="sysinfof" goto :SysInfoF:
if "!console!"=="ssploit" goto :SessionSploitA:
if "!console!"=="cmd" goto :startCMDA:
if "!console!"=="rshutdown" goto :startRemoteShutdown:
if "!console!"=="geolocateip" goto :geolocateip:
if "!console!"=="geolocatehost" goto :geolocatehost:
if "!console!"=="cls" goto :clear:
if "!console!"=="clear" goto :clear:
echo %Red%[ERROR] Unknown command entered: !console!. Type 'help' for a list of options.
goto :Main:


:Help:
echo %Green%-- Help Menu --
echo [help] Print out all commands [Functional]
echo [hostip] Get a ip from a hostname [Functional]
echo [iphost] Get a hostname from a ip [Functional]
echo [mlookup] Gets the local MAC address table [Functional]
echo [myip] Gets the local users ip [Functional]
echo [pcheck] Gets the local open ports list [Functional]
echo [cls / clear] Clears the console [Functional]
echo [speed] Sends 10 rapid requests to cloudflares 1.1.1.1 (Not Affiliated) [Functional]
echo [dlookup] Gets DNS Servers affiliated with a domain etc www.Google.com (Not Affiliated) [functional]
echo [sysinfo] Gets basic system information [Functional]
echo [sysinfof] Gets all system information [Functional]
echo [geolocateip] Geolocates a city/general location via ip (Recomended by Realthenoobie MC) [Not Tested]
echo [geolocatehost] Geolocates a city/general location via ip (Recomended by Realthenoobie MC) [Not Tested]
echo %Cyan%-- Applications --
echo %Green%[ssploit] Opens the sessionsploit application (Needs administrator) [Functional]
echo [cmd] Open command prompt as administrator (Needs administrator) [Functional]
echo [rshutdown] Open the remote shutdown menu [Functional]
goto :Main

:HostIp
set "hostname="
set /p hostname="%Red%RGSMenu %Green%(%Yellow%Hostname Input%Green%) %Yellow%>> "
if "%hostname%"=="" (
    echo %Red%[ERROR]%Reset% No hostname entered. Returning to Main Menu...
    goto Main
)

echo.
echo %Cyan%--- Resolving Hostname: %hostname% ---%Reset%



set "temp_ip="


for /f "tokens=2 delims=[]" %%i in ('ping -4 -n 1 -w 1000 %hostname% 2^>nul ^| findstr /i "["') do (
    set "temp_ip=%%i"
)

if defined temp_ip (
    echo.
    echo %Green%[SUCCESS]%Reset% Hostname "%hostname%" resolved to IP: %Red%!temp_ip!%Reset%
) else (
    echo.
    echo %Yellow%[FAIL]%Reset% Could not resolve the hostname "%hostname%". Check spelling or connectivity.
)


goto Main

:IpHost
set "ip_input="
set "resolved_host="

set /p ip_input="%Red%RGSMenu %Green%(%Yellow%IP Input%Green%) %Yellow%>> "

if "%ip_input%"=="" (
    echo %Red%[ERROR]%Reset% No IP address entered. Returning to Main Menu...
    goto Main
)

echo.
echo %Cyan%--- Reverse Resolving IP: %ip_input% ---%Reset%


for /f "tokens=2" %%i in ('ping -a -n 1 -w 1000 %ip_input% 2^>nul ^| findstr /i "Pinging"') do (
    set "resolved_host=%%i"
)

if "%resolved_host%"=="%ip_input%" set "resolved_host="

if defined resolved_host (
    echo.
    echo %Green%[SUCCESS]%Reset% IP "%ip_input%" resolved to Hostname: %Red%!resolved_host!%Reset%
) else (
    echo.
    echo %Yellow%[FAIL]%Reset% Could not resolve a hostname for "%ip_input%".
)

goto Main

:MacLookup
echo.
echo %Cyan%--- Fetching Local MAC Address Table (ARP) ---%Reset%
echo.
arp -a
echo.
goto Main

:MyIP
echo.
echo %Cyan%--- Gathering IP Information ---%Reset%
echo.
echo [Internal Local IPs]:
for /f "tokens=2 delims=:" %%i in ('ipconfig ^| findstr /i "IPv4"') do (
    echo  %%i
)
echo.
echo [External Public IP]:
for /f "delims=" %%i in ('curl -s ifconfig.me 2^>nul') do set "pub_ip=%%i"
if defined pub_ip (
    echo  !pub_ip!
) else (
    echo  Could not retrieve public IP.
)
echo.
goto Main

:PortCheck
echo.
echo %Cyan%--- Scanning Active Network Connections and Ports ---%Reset%
echo.
echo Proto  Local Address          Foreign Address        State
netstat -an | findstr /i "ESTABLISHED LISTENING"
echo.
goto Main

:clear
cls
goto label
goto Main

:DNSLookup
set "dns_target="
set /p dns_target="%Red%RGSMenu %Green%(%Yellow%Domain Input%Green%) %Yellow%>> "

if "%dns_target%"=="" (
    echo %Red%[ERROR]%Reset% No domain entered. Returning to Main Menu...
    goto Main
)

echo.
echo %Cyan%--- Querying DNS Records for %dns_target% ---%Reset%
echo.

nslookup %dns_target%

echo.
goto Main

:Speed
echo.
echo %Cyan%--- Testing Network Latency (10 Packets) ---%Reset%
echo.
ping -n 10 1.1.1.1
echo.
goto Main

:SysInfo
echo.
echo %Cyan%--- System Information Summary ---%Reset%
echo.
systeminfo | findstr /c:"OS Name" /c:"Total Physical Memory" /c:"Processor(s)"
echo %Cyan%--- Note: Run sysinfof to get full information ---%Reset%
echo.
goto Main

:SysInfoF
echo.
echo %Cyan%--- System Information Summary ---%Reset%
echo.
systeminfo
echo %Cyan%--- Note: Run sysinfo to get less information ---%Reset%
echo.
goto Main

:SessionSploitA
start "" "%appsfolder%\sessionsploit.exe"
goto :Main
:startCMDA
start "" "%appsfolder%\cmd"
goto :Main
:startRemoteShutdown
start shutdown /i
goto :Main

:geolocateip
set "ip_input="
set "country=" & set "region=" & set "city=" & set "isp="

set /p ip_input="%Red%RGSMenu %Green%(%Yellow%IP Input%Green%) %Yellow%>> %Reset%"

if "%ip_input%"=="" (
    echo %Red%[ERROR]%Reset% No IP address entered. Returning to Main Menu...
    pause
    goto Main
)

echo.
echo %Cyan%--- Fetching Geolocation for IP: %ip_input% ---%Reset%
echo %Blue%---------------------------------%Reset%

:: Fetch individual fields from ipinfo.io
for /f "tokens=*" %%A in ('curl -s "https://ipinfo.io/%ip_input%/country"') do set "country=%%A"
for /f "tokens=*" %%A in ('curl -s "https://ipinfo.io/%ip_input%/region"') do set "region=%%A"
for /f "tokens=*" %%A in ('curl -s "https://ipinfo.io/%ip_input%/city"') do set "city=%%A"
for /f "tokens=*" %%A in ('curl -s "https://ipinfo.io/%ip_input%/org"') do set "isp=%%A"

:: Check if we actually got data back (using country as the baseline check)
if defined country (
    echo.
    echo %Green%[SUCCESS]%Reset% Location data retrieved successfully.
    echo.
    echo %Green%Country:  %Yellow%%country%%Reset%
    echo %Green%Region:   %Yellow%%region%%Reset%
    echo %Green%City:     %Yellow%%city%%Reset%
    echo %Green%ISP:      %Yellow%%isp%%Reset%
) else (
    echo.
    echo %Yellow%[FAIL]%Reset% Could not fetch data for "%ip_input%". Check connection or IP.
)

echo %Blue%---------------------------------%Reset%
goto Main

:geolocatehost
set "host_input="
set "country=" & set "region=" & set "city=" & set "isp="

set /p host_input="%Red%RGSMenu %Green%(%Yellow%Hostname Input%Green%) %Yellow%>> %Reset%"

if "%host_input%"=="" (
    echo %Red%[ERROR]%Reset% No Hostname entered. Returning to Main Menu...
    pause
    goto Main
)

echo.
echo %Cyan%--- Resolving and Geolocating Hostname: %host_input% ---%Reset%
echo %Blue%---------------------------------%Reset%

:: ipinfo.io handles hostnames natively by resolving them first
for /f "tokens=*" %%A in ('curl -s "https://ipinfo.io/%host_input%/country"') do set "country=%%A"
for /f "tokens=*" %%A in ('curl -s "https://ipinfo.io/%host_input%/region"') do set "region=%%A"
for /f "tokens=*" %%A in ('curl -s "https://ipinfo.io/%host_input%/city"') do set "city=%%A"
for /f "tokens=*" %%A in ('curl -s "https://ipinfo.io/%host_input%/org"') do set "isp=%%A"

:: Check if the hostname resolved and returned data
if defined country (
    echo.
    echo %Green%[SUCCESS]%Reset% Hostname resolved and geolocated successfully.
    echo.
    echo %Green%Country:  %Yellow%%country%%Reset%
    echo %Green%Region:   %Yellow%%region%%Reset%
    echo %Green%City:     %Yellow%%city%%Reset%
    echo %Green%ISP:      %Yellow%%isp%%Reset%
) else (
    echo.
    echo %Yellow%[FAIL]%Reset% Could not resolve or fetch data for "%host_input%".
)

echo %Blue%---------------------------------%Reset%
goto Main